"use strict";
exports.id = 806;
exports.ids = [806];
exports.modules = {

/***/ 4661:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Constants = {
    domain:  false ? 0 : process.env.DOMAIN,
    apiBase: "https://api.masjid.net"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Constants);


/***/ }),

/***/ 6806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ DomainProvider),
/* harmony export */   "p": () => (/* binding */ DomainContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4661);



const DomainContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    domainDetails: null,
    setDomainDetails: (domainDetails)=>{}
});
const domainReducer = (state, action)=>{
    switch(action.type){
        case "SET":
            return {
                ...state,
                domainDetails: action.payload
            };
        default:
            return state;
    }
};
const DomainProvider = (props)=>{
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(domainReducer, {
        domainDetails: null
    });
    const setDomainDetails = (domainDetails)=>{
        console.log(domainDetails);
        dispatch({
            type: "SET",
            payload: domainDetails
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetch(`${_constants__WEBPACK_IMPORTED_MODULE_2__/* ["default"].apiBase */ .Z.apiBase}/saas/domain-details`).then((res)=>res.json().then((json)=>{
                if (res.ok) {
                    setDomainDetails(json);
                } else {
                    console.log(json);
                }
            }));
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DomainContext.Provider, {
        value: {
            domainDetails: state.domainDetails,
            setDomainDetails
        },
        ...props
    });
};



/***/ })

};
;