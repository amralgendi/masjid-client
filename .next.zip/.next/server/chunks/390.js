"use strict";
exports.id = 390;
exports.ids = [390];
exports.modules = {

/***/ 9390:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ AuthProvider),
/* harmony export */   "V": () => (/* binding */ AuthContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_3__]);
js_cookie__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    user: null,
    login: (tokens)=>{},
    logout: ()=>{}
});
const authReducer = (state, action)=>{
    switch(action.type){
        case "LOGIN":
            return {
                ...state,
                user: action.payload
            };
        case "LOGOUT":
            return {
                ...state,
                user: null
            };
        default:
            return state;
    }
};
const AuthProvider = (props)=>{
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(authReducer, {
        user: null
    });
    const login = (tokens)=>{
        js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].set("idToken", tokens.idToken, {
            domain: ".hello.localhost"
        });
        js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].set("accessToken", tokens.accessToken, {
            domain: ".hello.localhost"
        });
        js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].set("refreshToken", tokens.refreshToken, {
            domain: ".hello.localhost"
        });
        const decodedToken = jwt_decode__WEBPACK_IMPORTED_MODULE_2___default()(tokens.idToken);
        const appOrgUserRoleIds = !decodedToken["custom:appOrgUserRoles"] ? [] : decodedToken["custom:appOrgUserRoles"].split(",").map((id)=>id.trim());
        const user = {
            id: decodedToken.sub,
            isConfirmed: decodedToken.email_verified,
            email: decodedToken.email,
            appOrgUserRoleIds
        };
        dispatch({
            type: "LOGIN",
            payload: {
                data: user,
                tokens
            }
        });
    };
    const logout = ()=>{
        js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].remove("jwtTokens");
        dispatch({
            type: "LOGOUT"
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].get("idToken")) {
            const tokens = {
                idToken: js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].get("idToken"),
                accessToken: js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].get("accessToken"),
                refreshToken: js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].get("refreshToken")
            };
            const decodedToken = jwt_decode__WEBPACK_IMPORTED_MODULE_2___default()(tokens.idToken);
            if (decodedToken.exp * 1000 < Date.now()) {
                js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].remove("idToken", {
                    domain: ".hello.localhost"
                });
                js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].remove("accessToken", {
                    domain: ".hello.localhost"
                });
                js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].remove("refreshToken", {
                    domain: ".hello.localhost"
                });
            } else {
                login(tokens);
            }
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: {
            user: state.user,
            login,
            logout
        },
        ...props
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;